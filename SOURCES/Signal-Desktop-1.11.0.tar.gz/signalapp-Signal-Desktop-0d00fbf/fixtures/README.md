A collection of files for generating attachments for load testing. These files
were made available in the public domain.

Add more files to this directory for `Signal.Debug` to pick up.
