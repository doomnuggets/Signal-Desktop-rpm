export function deferredToPromise<T>(
  deferred: JQuery.Deferred<any, any, any>
): Promise<T>;
