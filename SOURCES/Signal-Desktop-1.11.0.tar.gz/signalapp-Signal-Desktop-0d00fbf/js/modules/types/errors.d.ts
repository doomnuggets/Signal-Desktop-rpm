export function toLogFormat(error: any): string;
