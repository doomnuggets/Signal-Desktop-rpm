/* global setTimeout */

exports.sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
