The simplest example of using the `<ConversationContext />` component:

```jsx
<util.ConversationContext theme={util.theme}>
  <div>Just a plain bit of text</div>
</util.ConversationContext>
```
