/**
 * @prettier
 */
export const TEXT_SECONDARY = '#bbb';
export const ICON_SECONDARY = '#ccc';
