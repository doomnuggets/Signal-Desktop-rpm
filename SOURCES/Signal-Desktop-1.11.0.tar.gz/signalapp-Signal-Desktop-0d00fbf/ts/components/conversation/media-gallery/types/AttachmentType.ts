/**
 * @prettier
 */
export type AttachmentType = 'media' | 'documents';
