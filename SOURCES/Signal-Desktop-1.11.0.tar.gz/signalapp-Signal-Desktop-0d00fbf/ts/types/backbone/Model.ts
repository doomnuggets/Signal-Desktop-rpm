export interface Model<T> {
  toJSON(): T;
}
