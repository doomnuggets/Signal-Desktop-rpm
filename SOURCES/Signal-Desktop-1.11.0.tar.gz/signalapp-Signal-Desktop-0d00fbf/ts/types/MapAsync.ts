export type MapAsync<T> = (value: T) => Promise<T>;
