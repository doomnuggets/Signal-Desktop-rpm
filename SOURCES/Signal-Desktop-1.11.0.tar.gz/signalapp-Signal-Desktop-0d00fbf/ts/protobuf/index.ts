import { signalservice as SignalService } from './compiled';

export { SignalService };
