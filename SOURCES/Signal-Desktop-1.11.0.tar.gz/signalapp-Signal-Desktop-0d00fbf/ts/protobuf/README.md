# Protocol Buffers

Placeholder directory for Protocol Buffers compiled to JavaScript / TypeScript.
